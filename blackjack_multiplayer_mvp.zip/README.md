# BlackJack Live — MVP inicial

Este projeto é uma primeira versão visual/interativa do site de Blackjack multiplayer.

## O que já está incluído
- Criar sala com código
- Entrar por código
- Mesa responsiva para PC e celular
- Dealer e jogadores
- Cartas e fichas virtuais
- Aposta
- Hit, Stand, Double e Split
- Embaralhar/reiniciar baralho
- Chat local da sala
- Painel de dealer
- Estrutura React + TypeScript + Vite

## Importante
Esta versão é um **protótipo frontend**. O multiplayer real ainda precisa de um backend com WebSocket/Socket.IO e banco de dados.

## Rodar
1. Instale Node.js 20+.
2. Abra a pasta no terminal.
3. Rode `npm install`.
4. Rode `npm run dev`.
5. Abra o endereço mostrado pelo Vite.

## Próxima etapa recomendada
Adicionar:
- servidor Node.js + Socket.IO;
- estado autoritativo da partida;
- salas reais;
- reconexão;
- autenticação;
- persistência;
- regras completas do Blackjack;
- permissões do dealer;
- histórico das rodadas.
