import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type Card = { suit: string; rank: string; hidden?: boolean };
type Player = { name: string; chips: number; bet: number; cards: Card[]; active: boolean };

const suits = ["♠", "♥", "♦", "♣"];
const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

function makeDeck(): Card[] {
  return suits.flatMap(suit => ranks.map(rank => ({ suit, rank })));
}

function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function CardView({ card }: { card: Card }) {
  if (card.hidden) return <div className="card back">★</div>;
  const red = card.suit === "♥" || card.suit === "♦";
  return <div className={"card " + (red ? "red" : "")}><span>{card.rank}</span><b>{card.suit}</b></div>;
}

function App() {
  const [screen, setScreen] = useState<"home" | "room">("home");
  const [room, setRoom] = useState("");
  const [name, setName] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [chips, setChips] = useState(1000);
  const [bet, setBet] = useState(100);
  const [status, setStatus] = useState("Aguardando aposta");
  const [deck, setDeck] = useState<Card[]>(() => shuffle(makeDeck()));
  const [dealer, setDealer] = useState<Card[]>([{suit:"♠",rank:"K",hidden:true},{suit:"♥",rank:"7"}]);
  const [hand, setHand] = useState<Card[]>([{suit:"♣",rank:"A"},{suit:"♦",rank:"8"}]);
  const [chat, setChat] = useState<string[]>(["Sistema: Bem-vindo à mesa!"]);
  const [message, setMessage] = useState("");
  const [players] = useState<Player[]>([
    { name: "Você", chips: 1000, bet: 100, cards: [{suit:"♣",rank:"A"},{suit:"♦",rank:"8"}], active:true },
    { name: "Jogador 2", chips: 850, bet: 50, cards: [], active:false },
  ]);

  const displayPlayers = useMemo(() => players, [players]);

  function enterRoom(create = false) {
    const code = create ? Math.random().toString(36).slice(2, 7).toUpperCase() : roomCode.trim().toUpperCase();
    if (!name.trim() || !code) return;
    setRoom(code);
    setScreen("room");
  }

  function placeBet(amount = bet) {
    if (amount < 10 || amount > chips) return;
    setChips(c => c - amount);
    setStatus(`Aposta de ${amount} fichas confirmada`);
  }

  function hit() {
    if (!deck.length) return;
    const [card, ...rest] = deck;
    setDeck(rest);
    setHand(h => [...h, card]);
    setStatus("Você recebeu uma carta");
  }

  function stand() {
    setStatus("Você ficou. Aguardando o dealer...");
  }

  function doubleDown() {
    if (bet > chips) return;
    setChips(c => c - bet);
    hit();
    setStatus("Double realizado");
  }

  function split() {
    if (hand.length === 2 && hand[0].rank === hand[1].rank) {
      setStatus("Split disponível para esta mão");
    } else {
      setStatus("Split só pode ser usado com cartas do mesmo valor");
    }
  }

  function shuffleDeck() {
    setDeck(shuffle(makeDeck()));
    setStatus("Baralho embaralhado");
  }

  function newRound() {
    const d = shuffle(makeDeck());
    setDeck(d.slice(4));
    setDealer([d[0], {...d[1], hidden:true}]);
    setHand([d[2], d[3]]);
    setStatus("Nova rodada iniciada");
  }

  function sendMessage() {
    if (!message.trim()) return;
    setChat(c => [...c, `${name || "Você"}: ${message.trim()}`]);
    setMessage("");
  }

  if (screen === "home") {
    return (
      <main className="home">
        <div className="glow"/>
        <section className="hero">
          <div className="brand"><span>♠</span> BLACKJACK <em>LIVE</em></div>
          <p className="tagline">Sua mesa virtual. Seus amigos. Uma partida em tempo real.</p>
          <div className="home-card">
            <label>Seu nome</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Digite seu nome" maxLength={20}/>
            <button className="primary" onClick={() => enterRoom(true)}>＋ Criar nova sala</button>
            <div className="divider"><span>ou entre em uma sala</span></div>
            <div className="join">
              <input value={roomCode} onChange={e => setRoomCode(e.target.value)} placeholder="Código da sala"/>
              <button onClick={() => enterRoom(false)}>Entrar</button>
            </div>
          </div>
          <div className="features">
            <span>🃏 Blackjack</span><span>👥 Multiplayer</span><span>💬 Chat</span><span>📱 Mobile</span>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="app">
      <header className="topbar">
        <div className="brand small"><span>♠</span> BLACKJACK <em>LIVE</em></div>
        <div className="room-pill">SALA <strong>{room}</strong></div>
        <div className="top-actions"><button onClick={() => navigator.clipboard?.writeText(room)}>🔗 Copiar convite</button><button onClick={() => setScreen("home")}>Sair</button></div>
      </header>

      <div className="layout">
        <section className="table-wrap">
          <div className="table">
            <div className="table-rim"/>
            <div className="dealer-area">
              <div className="seat-title">DEALER</div>
              <div className="cards">{dealer.map((c,i)=><CardView key={i} card={c}/>)}</div>
            </div>

            <div className="table-message">{status}</div>

            <div className="player-areas">
              {displayPlayers.map((p,i) => (
                <div className={"player-seat seat-"+i} key={p.name}>
                  <div className="avatar">{p.name.slice(0,1).toUpperCase()}</div>
                  <div><strong>{p.name}</strong><small>{i===0 ? `${chips} fichas` : `${p.chips} fichas`}</small></div>
                  <div className="mini-cards">{i===0 ? hand.map((c,j)=><CardView key={j} card={c}/>) : <span className="waiting">aguardando...</span>}</div>
                </div>
              ))}
            </div>

            <div className="controls">
              <div className="bet-box">
                <small>APOSTA</small>
                <strong>{bet}</strong>
                <div className="chip-row">
                  {[10,25,50,100,250].map(v=><button key={v} onClick={()=>setBet(v)}>{v}</button>)}
                </div>
                <button className="bet-btn" onClick={()=>placeBet()}>APOSTAR</button>
              </div>
              <div className="game-actions">
                <button onClick={hit}>HIT</button>
                <button onClick={stand}>STAND</button>
                <button onClick={doubleDown}>DOUBLE</button>
                <button onClick={split}>SPLIT</button>
              </div>
            </div>
          </div>
        </section>

        <aside className="sidebar">
          <div className="panel">
            <div className="panel-head"><h3>👥 Jogadores</h3><span>{displayPlayers.length}/7</span></div>
            {displayPlayers.map((p,i)=><div className="player-row" key={p.name}><div className="avatar mini">{p.name[0]}</div><div><strong>{p.name}</strong><small>{i===0 ? chips : p.chips} fichas</small></div><i className={p.active?"online":""}/></div>)}
          </div>
          <div className="panel chat">
            <div className="panel-head"><h3>💬 Chat</h3></div>
            <div className="messages">{chat.map((m,i)=><div key={i}>{m}</div>)}</div>
            <div className="chat-input"><input value={message} onChange={e=>setMessage(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendMessage()} placeholder="Mensagem..."/><button onClick={sendMessage}>➤</button></div>
          </div>
          <div className="panel dealer-panel">
            <div className="panel-head"><h3>🎩 Dealer</h3><span>CONTROLE</span></div>
            <button onClick={newRound}>▶ Nova rodada</button>
            <button onClick={shuffleDeck}>🔀 Embaralhar</button>
            <button onClick={()=>setStatus("Baralho reiniciado pelo dealer")}>↻ Reiniciar baralho</button>
          </div>
        </aside>
      </div>
    </main>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
